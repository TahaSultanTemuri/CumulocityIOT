import { Component } from '@angular/core';
import { DashboardClientComponent } from '../components/dashboard-client.component';

@Component({
  selector: 'app-dashboard-page',
  standalone: true,
  imports: [DashboardClientComponent],
  template: '<app-dashboard-client variant="full" />'
})
export class DashboardPageComponent {}
