import { Component } from '@angular/core';
import { DashboardClientComponent } from '../components/dashboard-client.component';

@Component({
  selector: 'app-dashboard-v2-page',
  standalone: true,
  imports: [DashboardClientComponent],
  template: '<app-dashboard-client variant="compact" />'
})
export class DashboardV2PageComponent {}
