import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import {
  PaymentRisk,
  StatusMeta,
  getTimelineInsights,
  parseTimeline
} from './utils/status-mapper';

@Component({
  selector: 'app-payment-timeline',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './payment-timeline.component.html'
})
export class PaymentTimelineComponent {
  @Input() summary: unknown;

  get timeline() {
    return parseTimeline(this.summary);
  }

  get insights() {
    return getTimelineInsights(this.timeline);
  }

  riskTone(risk: PaymentRisk): string {
    if (risk === 'High') return 'bg-red-50 text-red-700 ring-red-200';
    if (risk === 'Medium') return 'bg-amber-50 text-amber-700 ring-amber-200';
    return 'bg-emerald-50 text-emerald-700 ring-emerald-200';
  }

  latest(index: number): boolean {
    return index === this.timeline.length - 1;
  }

  trackNode(_index: number, item: StatusMeta): string {
    return item.code + item.label;
  }
}
