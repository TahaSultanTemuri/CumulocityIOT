﻿import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { ProductItem } from '../../core/models/types';
import { parseTimeline } from './utils/status-mapper';

type FieldItem = {
  label: string;
  value: string;
};

const PRODUCT_LABELS: Record<string, string> = {
  PLN: 'قرض شخصي',
  MTG: 'تمويل عقاري',
  CRC: 'بطاقة ائتمانية',
  BNPL: 'اشتر الآن وادفع لاحقاً'
};

const FREQUENCY_LABELS: Record<string, string> = {
  M: 'شهري',
  Q: 'ربع سنوي',
  S: 'نصف سنوي',
  A: 'سنوي',
  W: 'أسبوعي',
  D: 'يومي'
};

const SECURITY_LABELS: Record<string, string> = {
  NO: 'لايوجد',
  N: 'لايوجد',
  Y: 'موجود',
  YES: 'موجود'
};

@Component({
  selector: 'app-simah-style-product-summary',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './simah-style-product-summary.component.html'
})
export class SimahStyleProductSummaryComponent {
  @Input({ required: true }) product!: ProductItem;

  get details(): Record<string, unknown> {
    return this.product?.details && typeof this.product.details === 'object' && !Array.isArray(this.product.details)
      ? (this.product.details as Record<string, unknown>)
      : {};
  }

  get creditor(): string {
    return this.normalizeText(this.getValue('CI_CRDTR', this.product.bank));
  }

  get productType(): string {
    return this.mapProductType(this.getValue('CI_PRD', this.product.type));
  }

  get productStatus(): string {
    return this.normalizeText(this.product.status, '-');
  }

  get accountNumber(): string {
    return this.normalizeText(this.getValue('CI_ACC_NO', this.product.account_number));
  }

  get topMetrics(): FieldItem[] {
    return [
      { label: 'تاريخ الإصدار', value: this.normalizeDate(this.getValue('CI_ISSU_DT', this.product.issued_date)) },
      { label: 'حد الائتمان', value: this.normalizeNumber(this.getValue('CI_LIMIT', this.product.limit)) },
      { label: 'متوسط القسط الشهري', value: this.normalizeNumber(this.getValue('CI_AVG_INSTL', 0)) },
      { label: 'المبلغ المنتهي', value: this.normalizeNumber(this.getValue('CI_DAMOUNT', 0)) }
    ];
  }

  get rightFields(): FieldItem[] {
    return [
      { label: 'مبلغ القسط', value: this.normalizeNumber(this.getValue('CI_INSTL', 0)) },
      { label: 'الحد الأعلى لمبلغ القسط', value: this.normalizeNumber(this.getValue('CI_MIAMOUNT', 0)) },
      { label: 'نوع الضمان', value: this.mapSecurity(this.getValue('CI_SEC', 'NO')) },
      { label: 'المبالغ المتأخرة', value: this.normalizeNumber(this.getValue('CI_ODB', this.product.overdue_balance)) },
      { label: 'تاريخ آخر سداد', value: this.normalizeDate(this.getValue('CI_LAST_PAY_DT', this.product.last_payment_date)) },
      { label: 'تاريخ الفترة', value: this.normalizeDate(this.getValue('CI_AS_OF_DT', this.product.as_of_date)) },
      { label: 'المبلغ العمومي المصروف', value: this.normalizeNumber(this.getValue('CI_CUB', this.product.balance)) },
      { label: 'تاريخ الاستحقاق القادم', value: this.normalizeDate(this.getValue('CI_NXT_DU_DT', this.product.next_due_date)) },
      { label: 'طبيعة العقد', value: this.mapProductType(this.getValue('CI_PRD', this.product.type)) }
    ];
  }

  get leftFields(): FieldItem[] {
    return [
      { label: 'عدد الأقساط', value: this.normalizeText(this.getValue('CI_TNR', 0), '0') },
      { label: 'جدولة الدفعات', value: this.mapFrequency(this.getValue('CI_FRQ', 'M')) },
      { label: 'تاريخ الانتهاء', value: this.normalizeDate(this.getValue('CI_PROD_EXP_DT', '')) },
      { label: 'ضمان منح الراتب', value: this.mapSalary(this.getValue('CI_SAL', 'N')) },
      { label: 'تاريخ الإغلاق', value: this.normalizeDate(this.getValue('CI_CLSD_DT', this.product.closed_date)) },
      { label: 'مبلغ آخر سداد', value: this.normalizeNumber(this.getValue('CI_LAST_AMT_PD', this.product.last_payment_amount)) },
      {
        label: 'الدفعة المقدمة',
        value: this.normalizeNumber(this.getValue('CI_DPAYMENT', this.getValue('CI_BPAYMENT', 0)))
      },
      { label: 'حتى تاريخ', value: this.normalizeDate(this.getValue('CI_AS_OF_DT', this.product.as_of_date)) },
      { label: 'عدد الضامنين', value: this.normalizeText(this.getValue('CI_NOAPP', '-'), '-') }
    ];
  }

  get timeline() {
    return parseTimeline(this.getValue('CI_SUMMRY', this.product.ci_summary)).slice(-24);
  }

  getStatusDotClass(status: string): string {
    if (status.includes('مغلق')) return 'bg-[#1f7c95]';
    if (status.includes('متعثر')) return 'bg-[#8f2631]';
    return 'bg-[#1f7a43]';
  }

  private getValue(key: string, fallback?: unknown): unknown {
    const value = this.details[key];
    if (value === null || value === undefined || value === '') return fallback ?? '';
    return value;
  }

  private normalizeDate(value: unknown): string {
    const raw = String(value ?? '').trim();
    if (!raw) return '-';

    if (/^\d{2}\/\d{2}\/\d{4}$/.test(raw)) return raw;

    const parsed = new Date(raw);
    if (Number.isNaN(parsed.getTime())) return raw;

    const day = String(parsed.getDate()).padStart(2, '0');
    const month = String(parsed.getMonth() + 1).padStart(2, '0');
    const year = parsed.getFullYear();
    return `${day}/${month}/${year}`;
  }

  private normalizeNumber(value: unknown): string {
    if (value === null || value === undefined || value === '') return '0.00';

    const numeric =
      typeof value === 'number' ? value : Number(String(value).replace(/,/g, '').trim());

    if (!Number.isFinite(numeric)) return '0.00';

    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(numeric);
  }

  private normalizeText(value: unknown, fallback = '-'): string {
    const text = String(value ?? '').trim();
    return text || fallback;
  }

  private mapSecurity(value: unknown): string {
    const key = String(value ?? '').trim().toUpperCase();
    return SECURITY_LABELS[key] ?? this.normalizeText(value, 'لايوجد');
  }

  private mapFrequency(value: unknown): string {
    const key = String(value ?? '').trim().toUpperCase();
    return FREQUENCY_LABELS[key] ?? this.normalizeText(value, '-');
  }

  private mapSalary(value: unknown): string {
    const key = String(value ?? '').trim().toUpperCase();
    if (key === 'Y') return 'نعم';
    if (key === 'N') return 'لا';
    return this.normalizeText(value, '-');
  }

  private mapProductType(value: unknown): string {
    const key = String(value ?? '').trim().toUpperCase();
    return PRODUCT_LABELS[key] ?? this.normalizeText(value, '-');
  }
}
