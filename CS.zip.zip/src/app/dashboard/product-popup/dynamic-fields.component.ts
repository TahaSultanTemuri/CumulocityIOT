import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import {
  FieldSection,
  flattenObject,
  formatLabel,
  formatValue
} from './utils/formatters';

@Component({
  selector: 'app-dynamic-fields',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dynamic-fields.component.html'
})
export class DynamicFieldsComponent {
  @Input() sections: FieldSection[] = [];

  get preparedSections() {
    return this.sections
      .map((section) => {
        const flat = flattenObject(section.data ?? {});
        const entries = Object.entries(flat).filter(([, value]) => value !== undefined);

        return {
          ...section,
          entries
        };
      })
      .filter((section) => section.entries.length > 0);
  }

  formatLabel = formatLabel;
  formatValue = formatValue;
}
