import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { getStatusMap } from './utils/status-mapper';

@Component({
  selector: 'app-status-legend',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './status-legend.component.html'
})
export class StatusLegendComponent {
  readonly legendItems = Object.values(getStatusMap()).sort(
    (a, b) => a.severity - b.severity || a.code.localeCompare(b.code)
  );
}
