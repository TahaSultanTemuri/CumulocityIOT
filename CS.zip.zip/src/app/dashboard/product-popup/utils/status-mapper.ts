﻿export type PaymentRisk = 'Low' | 'Medium' | 'High';

export type StatusMeta = {
  code: string;
  label: string;
  tooltip: string;
  symbol: string;
  bgClass: string;
  textClass: string;
  ringClass: string;
  severity: number;
};

const STATUS_CONFIG: Record<string, Omit<StatusMeta, 'code'>> = {
  '0': {
    label: 'منتظم',
    tooltip: 'السداد منتظم',
    symbol: '✔️',
    bgClass: 'bg-[#1f7a43]',
    textClass: 'text-white',
    ringClass: 'ring-[#c9dfd2]',
    severity: 0
  },
  '1': {
    label: '1-30 يوم',
    tooltip: 'تأخير بسيط',
    symbol: '⏱',
    bgClass: 'bg-[#d9b434]',
    textClass: 'text-white',
    ringClass: 'ring-[#efe3b8]',
    severity: 1
  },
  '2': {
    label: '31-60 يوم',
    tooltip: 'تأخير متوسط',
    symbol: '⏱',
    bgClass: 'bg-[#df8d1f]',
    textClass: 'text-white',
    ringClass: 'ring-[#f1d1af]',
    severity: 2
  },
  '3': {
    label: '61-90 يوم',
    tooltip: 'تأخير مرتفع',
    symbol: '⏱',
    bgClass: 'bg-[#cf6d1f]',
    textClass: 'text-white',
    ringClass: 'ring-[#efc3a6]',
    severity: 3
  },
  '4': {
    label: '91-120 يوم',
    tooltip: 'تأخير عالي',
    symbol: '⏱',
    bgClass: 'bg-[#b74e28]',
    textClass: 'text-white',
    ringClass: 'ring-[#e8bbb0]',
    severity: 4
  },
  '5': {
    label: '121-150 يوم',
    tooltip: 'تأخير حرج',
    symbol: '⏱',
    bgClass: 'bg-[#992f34]',
    textClass: 'text-white',
    ringClass: 'ring-[#ddb2b6]',
    severity: 5
  },
  '6': {
    label: '151-180 يوم',
    tooltip: 'تأخير شديد جداً',
    symbol: '⏱',
    bgClass: 'bg-[#7f1f2f]',
    textClass: 'text-white',
    ringClass: 'ring-[#d3a9b2]',
    severity: 6
  },
  W: {
    label: 'متعثر',
    tooltip: 'المنتج متعثر',
    symbol: '⛔',
    bgClass: 'bg-[#8f2631]',
    textClass: 'text-white',
    ringClass: 'ring-[#d9b6bc]',
    severity: 7
  },
  M: {
    label: 'لم يتم التحديث',
    tooltip: 'لا يوجد تحديث لهذا الشهر',
    symbol: '➖',
    bgClass: 'bg-[#9ea7b1]',
    textClass: 'text-white',
    ringClass: 'ring-[#d6dbe0]',
    severity: 0
  },
  R: {
    label: 'دفعة مؤجلة',
    tooltip: 'تمت جدولة الدفعة',
    symbol: '⏸',
    bgClass: 'bg-[#7f273f]',
    textClass: 'text-white',
    ringClass: 'ring-[#d7b0bc]',
    severity: 2
  },
  C: {
    label: 'منتج مغلق',
    tooltip: 'الحساب مغلق',
    symbol: '🔒',
    bgClass: 'bg-[#1f7c95]',
    textClass: 'text-white',
    ringClass: 'ring-[#b7d9e4]',
    severity: 0
  }
};

const LATE_CODES = new Set(['1', '2', '3', '4', '5', '6', 'W']);

function createFallbackMeta(code: string): StatusMeta {
  return {
    code,
    label: `رمز غير معروف (${code})`,
    tooltip: 'لا يوجد توصيف لهذا الرمز',
    symbol: '➖',
    bgClass: 'bg-slate-300',
    textClass: 'text-slate-700',
    ringClass: 'ring-slate-200',
    severity: 1
  };
}

export function getStatusMeta(code: string): StatusMeta {
  const normalized = (code || '').trim().toUpperCase();
  const config = STATUS_CONFIG[normalized];

  if (!config) return createFallbackMeta(normalized || '-');
  return {
    code: normalized,
    ...config
  };
}

export function getStatusMap(): Record<string, StatusMeta> {
  return Object.fromEntries(
    Object.entries(STATUS_CONFIG).map(([code, config]) => [
      code,
      {
        code,
        ...config
      }
    ])
  );
}

export function parseTimeline(value: unknown): StatusMeta[] {
  if (value === null || value === undefined) return [];

  const timeline = String(value).trim();
  if (!timeline || timeline === '-') return [];

  return timeline
    .split('')
    .filter((char) => char.trim().length > 0)
    .map((char) => getStatusMeta(char));
}

export function getTimelineInsights(items: StatusMeta[]): {
  latePayments: number;
  worstStatus: StatusMeta | null;
  risk: PaymentRisk;
} {
  if (items.length === 0) {
    return {
      latePayments: 0,
      worstStatus: null,
      risk: 'Low'
    };
  }

  const latePayments = items.reduce(
    (count, item) => count + (LATE_CODES.has(item.code) ? 1 : 0),
    0
  );

  const worstStatus = items.reduce<StatusMeta | null>((worst, current) => {
    if (!worst) return current;
    return current.severity > worst.severity ? current : worst;
  }, null);

  const risk: PaymentRisk =
    latePayments >= 6 || (worstStatus?.severity ?? 0) >= 6
      ? 'High'
      : latePayments >= 2 || (worstStatus?.severity ?? 0) >= 3
        ? 'Medium'
        : 'Low';

  return {
    latePayments,
    worstStatus,
    risk
  };
}
