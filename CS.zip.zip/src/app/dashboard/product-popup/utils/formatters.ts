﻿const NUMBER_FORMATTER = new Intl.NumberFormat("en-US", {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
});

const EXACT_LABELS: Record<string, string> = {
  credit_limit: "حد الائتمان",
  installment_amount: "مبلغ القسط",
  ci_limit: "حد الائتمان",
  ci_instl: "مبلغ القسط",
  ci_acc_no: "رقم الحساب",
  ci_crdtr: "الجهة",
  ci_prd: "المنتج",
  ci_subprod: "المنتج الفرعي",
  ci_status: "الحالة",
  ci_cub: "الرصيد الحالي",
  ci_odb: "المبلغ المتأخر",
  ci_issu_dt: "تاريخ الإصدار",
  ci_as_of_dt: "تاريخ البيانات",
  ci_last_pay_dt: "تاريخ آخر سداد",
  ci_last_amt_pd: "مبلغ آخر سداد",
  ci_nxt_du_dt: "تاريخ الاستحقاق القادم",
  ci_clsd_dt: "تاريخ الإغلاق",
  ci_summry: "ملخص حالات السداد"
};

const TOKEN_LABELS: Record<string, string> = {
  ci: "ائتماني",
  credit: "ائتمان",
  limit: "حد",
  installment: "قسط",
  amount: "مبلغ",
  account: "حساب",
  number: "رقم",
  bank: "جهة",
  creditor: "جهة",
  product: "منتج",
  sub: "فرعي",
  status: "حالة",
  balance: "رصيد",
  overdue: "متأخر",
  issued: "إصدار",
  issue: "إصدار",
  date: "تاريخ",
  next: "قادم",
  due: "استحقاق",
  closed: "إغلاق",
  close: "إغلاق",
  summary: "ملخص",
  payment: "سداد",
  last: "آخر",
  avg: "متوسط",
  joint: "مشترك",
  no: "عدد",
  sec: "ضمان",
  sal: "راتب",
  tnr: "مدة",
  frq: "تكرار",
  details: "تفاصيل"
};

const DATE_PATTERN = /^\d{2}\/\d{2}\/\d{4}$/;

function isArabicText(value: string): boolean {
  return /[\u0600-\u06FF]/.test(value);
}

function normalizeKey(input: string): string {
  return input
    .replace(/([a-z0-9])([A-Z])/g, "$1_$2")
    .replace(/[^a-zA-Z0-9]+/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_|_$/g, "")
    .toLowerCase();
}

function formatDate(input: string): string {
  if (DATE_PATTERN.test(input)) {
    const [day, month, year] = input.split("/").map((part) => Number(part));
    const date = new Date(year, month - 1, day);
    if (!Number.isNaN(date.getTime())) {
      return new Intl.DateTimeFormat("ar-SA-u-ca-gregory-nu-latn", {
        day: "2-digit",
        month: "long",
        year: "numeric"
      }).format(date);
    }
  }

  const parsed = new Date(input);
  if (Number.isNaN(parsed.getTime())) return input;

  return new Intl.DateTimeFormat("ar-SA-u-ca-gregory-nu-latn", {
    day: "2-digit",
    month: "long",
    year: "numeric"
  }).format(parsed);
}

export function formatLabel(key: string): string {
  if (!key) return "-";
  if (isArabicText(key)) return key;

  const normalized = normalizeKey(key);
  if (EXACT_LABELS[normalized]) return EXACT_LABELS[normalized];

  const tokens = normalized.split("_").filter(Boolean);
  const translated = tokens.map((token) => TOKEN_LABELS[token] ?? token.toUpperCase());

  if (translated.length > 0) {
    return translated.join(" ");
  }

  return key;
}

export function formatValue(value: unknown): string {
  if (value === null || value === undefined) return "-";

  if (typeof value === "number") {
    if (Number.isNaN(value)) return "-";
    return NUMBER_FORMATTER.format(value);
  }

  if (typeof value === "boolean") {
    return value ? "نعم" : "لا";
  }

  if (typeof value === "string") {
    const trimmed = value.trim();
    if (!trimmed) return "-";

    if (DATE_PATTERN.test(trimmed) || /\d{4}-\d{2}-\d{2}/.test(trimmed)) {
      return formatDate(trimmed);
    }

    return trimmed;
  }

  if (Array.isArray(value)) {
    if (value.length === 0) return "-";
    return value.map((item) => formatValue(item)).join("، ");
  }

  if (typeof value === "object") {
    const entries = Object.entries(value as Record<string, unknown>);
    if (entries.length === 0) return "-";
    return entries
      .map(([key, nestedValue]) => `${formatLabel(key)}: ${formatValue(nestedValue)}`)
      .join(" | ");
  }

  return String(value);
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function flattenObject(
  input: Record<string, unknown>,
  parentKey = ""
): Record<string, unknown> {
  const output: Record<string, unknown> = {};

  for (const [key, value] of Object.entries(input)) {
    const compoundKey = parentKey ? `${parentKey}_${key}` : key;

    if (isPlainObject(value)) {
      Object.assign(output, flattenObject(value, compoundKey));
      continue;
    }

    output[compoundKey] = value;
  }

  return output;
}

export type FieldSection = {
  id: string;
  title: string;
  data: Record<string, unknown>;
};
