import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
  Component,
  DestroyRef,
  Input,
  computed,
  effect,
  inject,
  signal
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { AnalyzeApiService } from '../../core/services/analyze-api.service';
import {
  DefaultItem,
  FullResponse,
  InputSource,
  ProductItem,
  RiskResponse
} from '../../core/models/types';
import { formatMoney, formatPercent } from '../../core/utils/format';
import { SimahStyleProductSummaryComponent } from '../product-popup/simah-style-product-summary.component';

export type DashboardVariant = 'full' | 'compact';
export type DashboardTab = 'المنتجات' | 'الاستعلامات' | 'المتعثّرات' | 'تفاصيل الدرجة';

const ALL = 'الكل';

@Component({
  selector: 'app-dashboard-client',
  standalone: true,
  imports: [CommonModule, SimahStyleProductSummaryComponent],
  templateUrl: './dashboard-client.component.html'
})
export class DashboardClientComponent {
  @Input() variant: DashboardVariant = 'full';

  readonly dashboardTabs: DashboardTab[] = [
    'المنتجات',
    'الاستعلامات',
    'المتعثّرات',
    'تفاصيل الدرجة'
  ];

  readonly data = signal<FullResponse | null>(null);
  readonly error = signal<string | null>(null);
  readonly loading = signal(true);
  readonly source = signal<InputSource>('input_2');
  readonly activeTab = signal<DashboardTab>(this.dashboardTabs[0]);

  readonly search = signal('');
  readonly bankFilter = signal(ALL);
  readonly statusFilter = signal(ALL);
  readonly typeFilter = signal(ALL);
  readonly selectedProduct = signal<ProductItem | null>(null);

  readonly isCompact = computed(() => this.variant === 'compact');

  readonly operationalDate = computed(() =>
    new Intl.DateTimeFormat('ar-SA-u-ca-gregory', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }).format(new Date())
  );

  readonly priorityLabel = computed(() => {
    const level = this.data()?.overview.risk_level;
    if (level === 'HIGH') return 'أولوية عالية';
    if (level === 'MEDIUM') return 'أولوية متوسطة';
    return 'أولوية منخفضة';
  });

  readonly products = computed(() => this.data()?.products.products ?? []);

  readonly normalizedSearch = computed(() => this.search().trim().toLowerCase());

  readonly filteredProducts = computed(() =>
    this.products().filter((product) => {
      const matchesSearch = !this.normalizedSearch() || this.productMatchesSearch(product);
      const matchesBank = this.bankFilter() === ALL || product.bank === this.bankFilter();
      const matchesStatus = this.statusFilter() === ALL || product.status === this.statusFilter();
      const matchesType = this.typeFilter() === ALL || product.type === this.typeFilter();

      return matchesSearch && matchesBank && matchesStatus && matchesType;
    })
  );

  readonly bankScopedProducts = computed(() =>
    this.products().filter((product) => {
      const matchesStatus = this.statusFilter() === ALL || product.status === this.statusFilter();
      const matchesType = this.typeFilter() === ALL || product.type === this.typeFilter();
      return this.productMatchesSearch(product) && matchesStatus && matchesType;
    })
  );

  readonly statusScopedProducts = computed(() =>
    this.products().filter((product) => {
      const matchesBank = this.bankFilter() === ALL || product.bank === this.bankFilter();
      const matchesType = this.typeFilter() === ALL || product.type === this.typeFilter();
      return this.productMatchesSearch(product) && matchesBank && matchesType;
    })
  );

  readonly typeScopedProducts = computed(() =>
    this.products().filter((product) => {
      const matchesBank = this.bankFilter() === ALL || product.bank === this.bankFilter();
      const matchesStatus = this.statusFilter() === ALL || product.status === this.statusFilter();
      return this.productMatchesSearch(product) && matchesBank && matchesStatus;
    })
  );

  readonly banks = computed(() => [
    ALL,
    ...Array.from(new Set(this.bankScopedProducts().map((product) => product.bank))).sort()
  ]);

  readonly statuses = computed(() => [
    ALL,
    ...Array.from(new Set(this.statusScopedProducts().map((product) => product.status))).sort()
  ]);

  readonly types = computed(() => [
    ALL,
    ...Array.from(new Set(this.typeScopedProducts().map((product) => product.type))).sort()
  ]);

  readonly hasActiveFilters = computed(
    () =>
      !!this.search() ||
      this.bankFilter() !== ALL ||
      this.statusFilter() !== ALL ||
      this.typeFilter() !== ALL
  );

  readonly shouldShowRows = computed(() => this.hasActiveFilters());
  readonly visibleProducts = computed(() =>
    this.shouldShowRows() ? this.filteredProducts() : []
  );

  readonly destroyRef = inject(DestroyRef);
  private readonly api = inject(AnalyzeApiService);
  private requestCounter = 0;

  constructor() {
    effect(() => {
      this.load(this.source());
    });

    effect((onCleanup) => {
      if (!this.selectedProduct()) return;

      const previousOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';

      onCleanup(() => {
        document.body.style.overflow = previousOverflow;
      });
    });
  }

  formatMoney = formatMoney;
  formatPercent = formatPercent;

  setSource(source: InputSource): void {
    this.source.set(source);
  }

  setActiveTab(tab: DashboardTab): void {
    this.activeTab.set(tab);
  }

  isProductsTab(): boolean {
    return this.activeTab() === this.dashboardTabs[0];
  }

  isEnquiriesTab(): boolean {
    return this.activeTab() === this.dashboardTabs[1];
  }

  isDefaultsTab(): boolean {
    return this.activeTab() === this.dashboardTabs[2];
  }

  onSearchChange(value: string): void {
    this.search.set(value);
  }

  onBankChange(value: string): void {
    this.bankFilter.set(value);
  }

  onStatusChange(value: string): void {
    this.statusFilter.set(value);
  }

  onTypeChange(value: string): void {
    this.typeFilter.set(value);
  }

  resetFilters(): void {
    this.search.set('');
    this.bankFilter.set(ALL);
    this.statusFilter.set(ALL);
    this.typeFilter.set(ALL);
  }

  handleJump(target: string): void {
    if (target === 'products-tab') {
      this.openTabAndScroll(this.dashboardTabs[0]);
      return;
    }

    if (target === 'enquiries-tab') {
      this.openTabAndScroll(this.dashboardTabs[1]);
      return;
    }

    if (target === 'score-tab') {
      this.openTabAndScroll(this.dashboardTabs[3]);
      return;
    }

    if (target === 'defaults-tab') {
      this.openTabAndScroll(this.dashboardTabs[2]);
      return;
    }

    this.scrollToSection(target);
  }

  openDetails(product: ProductItem): void {
    if (!this.isCompact()) return;
    this.selectedProduct.set(product);
  }

  closeDetails(): void {
    this.selectedProduct.set(null);
  }

  tabCount(tab: DashboardTab, data: FullResponse): number {
    if (tab === 'المنتجات') return data.products.products.length;
    if (tab === 'الاستعلامات') return data.enquiries.recent_enquiries.length;
    if (tab === 'المتعثّرات') return data.defaults.defaults.length;
    return 3;
  }

  scoreBandLabel(band: FullResponse['overview']['score_band']): string {
    if (band === 'HIGH') return 'مرتفع';
    if (band === 'MEDIUM') return 'متوسط';
    return 'منخفض';
  }

  confidenceTone(confidence: FullResponse['insights']['confidence_feel']): string {
    if (confidence === 'HIGH') return 'text-emerald-700 bg-emerald-100';
    if (confidence === 'MEDIUM') return 'text-amber-700 bg-amber-100';
    return 'text-slate-700 bg-slate-100';
  }

  confidenceLabel(confidence: FullResponse['insights']['confidence_feel']): string {
    if (confidence === 'HIGH') return 'مرتفع';
    if (confidence === 'MEDIUM') return 'متوسط';
    return 'منخفض';
  }

  intentTone(intent: FullResponse['insights']['likely_intent']): string {
    if (intent === 'ASK_SCORE') return 'bg-red-50 text-red-700 ring-red-200';
    if (intent === 'ASK_ENQUIRIES') return 'bg-amber-50 text-amber-700 ring-amber-200';
    return 'bg-slate-100 text-slate-700 ring-slate-200';
  }

  intentLabel(intent: FullResponse['insights']['likely_intent']): string {
    if (intent === 'ASK_SCORE') return 'أولوية شرح الدرجة';
    if (intent === 'ASK_ENQUIRIES') return 'أولوية مراجعة الاستعلامات';
    return 'أولوية مراجعة المنتجات';
  }

  intentTitle(intent: FullResponse['insights']['likely_intent']): string {
    if (intent === 'ASK_SCORE') return 'استفسار عن الدرجة الائتمانية';
    if (intent === 'ASK_ENQUIRIES') return 'استفسار عن الاستعلامات';
    return 'استفسار عن المنتجات';
  }

  flagLabel(flag: string): string {
    if (flag === 'LOW_SCORE') return 'درجة منخفضة';
    if (flag === 'HIGH_EXPOSURE') return 'استهلاك مرتفع';
    if (flag === 'RECENT_ENQUIRIES') return 'استعلامات حديثة';
    return flag;
  }

  flagDescription(flag: string): string {
    if (flag === 'LOW_SCORE') return 'الدرجة الائتمانية منخفضة ومن المتوقع أن تكون محور المكالمة.';
    if (flag === 'HIGH_EXPOSURE') return 'الاستهلاك مرتفع مقارنة بإجمالي الحدود المتاحة.';
    if (flag === 'RECENT_ENQUIRIES') return 'وجود استعلامات حديثة قد يعني بحثًا نشطًا عن تمويل جديد.';
    return flag;
  }

  defaultsTrackBy(index: number, item: DefaultItem): string {
    return `${item.bank}-${item.account_number}-${index}`;
  }

  riskFlagsCount(risk: RiskResponse): number {
    return risk.risk_flags.length + (risk.has_default ? 1 : 0);
  }

  private load(source: InputSource): void {
    const requestId = ++this.requestCounter;

    this.loading.set(true);
    this.error.set(null);

    this.api
      .getAnalysis(source)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (payload) => {
          if (requestId !== this.requestCounter) return;
          this.data.set(payload);
          this.loading.set(false);
        },
        error: (apiError: HttpErrorResponse) => {
          if (requestId !== this.requestCounter) return;
          this.error.set('تعذر تحميل بيانات التحليل.');
          this.loading.set(false);
          console.error(apiError);
        }
      });
  }

  private openTabAndScroll(tab: DashboardTab): void {
    this.activeTab.set(tab);

    requestAnimationFrame(() => {
      this.scrollToSection('score-details');
    });
  }

  private scrollToSection(sectionId: string): void {
    const section = document.querySelector<HTMLElement>(`#${sectionId}`);
    if (!section) return;

    const top = window.scrollY + section.getBoundingClientRect().top - 24;
    window.scrollTo({ top, behavior: 'smooth' });
  }

  private productMatchesSearch(product: ProductItem): boolean {
    const normalizedSearch = this.normalizedSearch();
    if (!normalizedSearch) return true;

    return [
      product.bank,
      product.account_number,
      product.type,
      product.sub_product,
      product.ci_summary
    ]
      .filter(Boolean)
      .some((value) => String(value).toLowerCase().includes(normalizedSearch));
  }
}
