import { Routes } from '@angular/router';
import { DashboardPageComponent } from './dashboard/pages/dashboard-page.component';
import { DashboardV2PageComponent } from './dashboard/pages/dashboard-v2-page.component';
import { HomePageComponent } from './home/pages/home-page.component';

export const routes: Routes = [
  {
    path: '',
    component: HomePageComponent
  },
  {
    path: 'dashboard',
    component: DashboardPageComponent
  },
  {
    path: 'dashboard-v2',
    component: DashboardV2PageComponent
  },
  {
    path: '**',
    redirectTo: ''
  }
];
