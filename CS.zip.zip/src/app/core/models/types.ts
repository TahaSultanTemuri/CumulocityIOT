export type ScoreBand = 'LOW' | 'MEDIUM' | 'HIGH';
export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH';
export type RiskFlag = 'LOW_SCORE' | 'HIGH_EXPOSURE' | 'RECENT_ENQUIRIES';
export type LikelyIntent = 'ASK_SCORE' | 'ASK_ENQUIRIES' | 'ASK_PRODUCTS';
export type InputSource = 'input' | 'input_2';

export interface Overview {
  customer_id: string;
  national_id: string;
  phone_number: string;
  name: string;
  report_date: string | null;
  score: number;
  score_band: ScoreBand;
  risk_level: RiskLevel;
}

export interface ProductItem {
  bank: string;
  type: string;
  status: string;
  account_number: string;
  limit: number;
  overdue_balance: number;
  balance: number;
  issued_date: string | null;
  last_payment_date: string | null;
  last_payment_amount: number;
  as_of_date: string | null;
  next_due_date: string | null;
  closed_date: string | null;
  ci_summary: string | null;
  sub_product: string | null;
  details: Record<string, unknown>;
}

export interface ProductsResponse {
  total_accounts: number;
  active_accounts: number;
  closed_accounts: number;
  outstanding_obligations: number;
  products: ProductItem[];
}

export interface EnquiryItem {
  date: string | null;
  bank: string;
  type: string;
  product: string;
  amount: number;
  reason: string | null;
}

export interface EnquiriesResponse {
  total_enquiries: number;
  last_30_days: number;
  last_60_days: number;
  last_90_days: number;
  grouped_by_bank: Record<string, number>;
  grouped_by_type: Record<string, number>;
  recent_enquiries: EnquiryItem[];
}

export interface RiskResponse {
  has_default: boolean;
  total_liabilities: number;
  total_limits: number;
  utilization_ratio: number;
  risk_flags: RiskFlag[];
}

export interface DefaultItem {
  bank: string;
  product: string;
  account_number: string;
  load_date: string | null;
  original_amount: number;
  current_balance: number;
  status: string;
  settled_date: string | null;
}

export interface DefaultsResponse {
  total_defaults: number;
  active_defaults_count: number;
  total_default_amount: number;
  active_default_amount: number;
  defaults: DefaultItem[];
}

export interface InsightsResponse {
  likely_intent: LikelyIntent;
  likely_questions: string[];
  key_insights: string[];
  next_best_action: string;
  confidence_feel: 'LOW' | 'MEDIUM' | 'HIGH';
}

export interface FullResponse {
  overview: Overview;
  products: ProductsResponse;
  enquiries: EnquiriesResponse;
  risk: RiskResponse;
  defaults: DefaultsResponse;
  insights: InsightsResponse;
}
