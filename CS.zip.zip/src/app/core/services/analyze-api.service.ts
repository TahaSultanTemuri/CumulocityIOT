import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { FullResponse, InputSource } from '../models/types';

@Injectable({ providedIn: 'root' })
export class AnalyzeApiService {
  constructor(private readonly http: HttpClient) {}

  getAnalysis(source: InputSource): Observable<FullResponse> {
    const params = new HttpParams().set('source', source);
    return this.http.get<FullResponse>('/api/analyze', { params });
  }
}
