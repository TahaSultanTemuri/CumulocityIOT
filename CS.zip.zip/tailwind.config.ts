import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{html,ts}'],
  theme: {
    extend: {
      colors: {
        ink: { 950: '#08111f' },
        slatebrand: {
          50: '#f4f7fb',
          100: '#e9eff8',
          200: '#cedcf0',
          300: '#a7c0e2',
          400: '#749bcf',
          500: '#4f7bb7',
          600: '#3d6098',
          700: '#344e7b',
          800: '#304465',
          900: '#2d3a55'
        }
      },
      boxShadow: {
        panel: '0 10px 30px rgba(8, 17, 31, 0.08)'
      },
      backgroundImage: {
        'dashboard-grid':
          'linear-gradient(to right, rgba(79,123,183,0.08) 1px, transparent 1px), linear-gradient(to bottom, rgba(79,123,183,0.08) 1px, transparent 1px)'
      }
    }
  },
  plugins: []
};

export default config;
